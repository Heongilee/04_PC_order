public class TEST{
	public static void main(String[] args){
		System.out.println("HeongiLee's Command Line");
		System.out.println("ZeroHyun's Command Line");
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
	}
}