package Controller;

//C_ProdManager.java에서 구현할 인터페이스
public interface I_ProdManager {
	void show();		// 조회
	void insertion();	// 등록 및 수정
	void deletion();	// 삭제
}
