package Controller;

// C_AdminView.java에서 구현할 인터페이스
public interface I_AdminView {
	void Goto_CustomerManager();	//고객관리 페이지로 이동한다.
	void Goto_ProductManager();		//상품관리 페이지로 이동한다.
}
